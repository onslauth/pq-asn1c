#ifndef	_ASN1FIX_BIT_STRING_H_
#define	_ASN1FIX_BIT_STRING_H_

int asn1f_fix_bit_string(arg_t *);

#endif	/* _ASN1FIX_BIT_STRING_H_ */
