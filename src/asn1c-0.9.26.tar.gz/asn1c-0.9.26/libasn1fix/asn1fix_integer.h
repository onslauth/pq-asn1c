#ifndef	_ASN1FIX_INTEGER_H_
#define	_ASN1FIX_INTEGER_H_

int asn1f_fix_integer(arg_t *);		/* Type1 ::= INTEGER { a(1), b(2) } */

#endif	/* _ASN1FIX_INTEGER_H_ */
