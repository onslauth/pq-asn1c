#ifndef	_ASN1C_SAVE_H_
#define	_ASN1C_SAVE_H_

int asn1c_save_compiled_output(arg_t *arg, const char *datadir,
	int argc, int optc, char **argv);

#endif	/* _ASN1C_SAVE_H_ */
